package com.example.test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import android.support.v7.app.ActionBarActivity;
import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class Exercise2 extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_exercise2);
		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		
		IotdHandler handler = new IotdHandler();
		//NasaIotd handler = new NasaIotd();		
		//handler.refreshFromFeed();
		URL url = null;
		try {
			url = new URL("http://www.nasa.gov/rss/dyn/lg_image_of_the_day.rss");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		handler.processFeed(this, url);
		try {
			resetDisplay(handler.getTitle(),handler.getDate(),new URL(handler.getUrl()),handler.getDescription());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.exercise2, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private void resetDisplay(String title, String date, URL imageUrl,
			String description) {
		TextView titleView = (TextView)findViewById(R.id.imageTitle);
		TextView dateView = (TextView)findViewById(R.id.imageDate);
		TextView descriptionView = (TextView)findViewById(R.id.imageDescription);
		ImageView imageView = (ImageView)findViewById(R.id.imageDisplay);	
		
		titleView.setText(title);
		dateView.setText(date);
		descriptionView.setText(description);		

		try {
			Bitmap bmp;
			bmp = BitmapFactory.decodeStream(imageUrl.openStream());
			imageView.setImageBitmap(bmp);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}
	
	public void refresh(View v){
		ProgressDialog dialog = ProgressDialog.show(this,"laoding","Loading the image of the day");
	}
	
	public void toast(View v){
		Toast.makeText(this,"wallpaper ser",Toast.LENGTH_SHORT).show();
	}
	
}
